<?php
return array(
		'controllers' => array(
			'invokables' => array(
				'client' => 'Client\Controller\ClientController',
					),
					),
		
		'router' => array(
				'routes' => array(
					'client' => array(
					'type' => 'segment',
					'options' => array(
							'route' => '/client[/:action][/:id]',
							'constraints' => array(
									'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
									'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
									
										),

					

					'defaults' => array(
							'controller' => 'client',
							'action' => 'index',
							   ),
							   ),
						  ),

					),
					

				),

				'child_routes' => array(
							'default' => array(
							'type'    => 'segment',
							'options' => array(
							'route'    => '/client[/:action][/:id]]',
							'constraints' => array(
										'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
										'action'     => '[a-zA-Z][a-zA-Z0-9_-]*',
										),
									  ),

									   ),
							),


		'view_manager' => array(
				'display_not_found_reason' => true,
				'display_exceptions'       => true,
				'doctype'                  => 'HTML5',
				'not_found_template'       => 'error/404',
				'exception_template'       => 'error/index',
				'template_map' => array(
						'client/layout'		  =>__DIR__ . '/../view/layout/client-layout.phtml',
						'client/client/index' => __DIR__ . '/../view/client/client/index.phtml',
						'error/404'               => __DIR__ . '/../view/error/404.phtml',
						'error/index'             => __DIR__ . '/../view/error/index.phtml',
				),
				'template_path_stack' => array(
					'client' => __DIR__ . '/../view',
							),
				'strategies' => array(
						'ViewJsonStrategy',
					 ),
							),
);
