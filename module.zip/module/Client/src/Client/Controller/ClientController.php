<?php
namespace Client\Controller;
 
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Http\Request;
use Zend\Http\Client;
use Zend\Stdlib\Parameters;
use Zend\View\Model\JsonModel;
use Administration\Model\Entity\Cache;
 
class ClientController extends AbstractActionController
{

	
	public function indexAction(){
		$this->layout('layout/client-layout');
		$type_annonce = $this->getAnnonceTypes();
		$type_bien = $this->getBienTypes();
		return new ViewModel(array('types'=>$type_annonce,'bien'=>$type_bien));
	}
	public function estimateAction(){
		$this->layout('layout/client-layout');
		$wilayas = $this->getWilayas();
		return new ViewModel(array('wilayas'=>$wilayas));
	}
	public function heatmapAction(){
		$this->layout('layout/client-layout');
		$type_annonce = $this->getAnnonceTypes();
		$type_bien = $this->getBienTypes();
		return new ViewModel(array('types'=>$type_annonce,'bien'=>$type_bien));
	}
	public function heatmap1Action(){
		$this->layout('layout/client-layout');
		$type_annonce = $this->getAnnonceTypes();
		$type_bien = $this->getBienTypes();
		return new ViewModel(array('types'=>$type_annonce,'bien'=>$type_bien));
	}
	public function presentationAction(){
		$this->layout('layout/client-layout');
		return new ViewModel();
	}
	public function contactAction(){
		$this->layout('layout/client-layout');
		return new ViewModel();
	}
	public function displayDetailsAction(){
			$id = $this->params ('id');
			//solliciter le service REST
			$request = new Request();
			$request->getHeaders()->addHeaders(array(
				'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
			));
			$request->setUri("http://darna.admin/services/getAnnonceDetails?id=$id");
			$request->setMethod('GET');
			
			$client = new Client();
			$response = $client->dispatch($request);
			$ret = json_decode($response->getContent(), true);
			
			
			$this->layout('layout/client-layout');;
			if($ret['status']=='FAILURE') $viewModel = new ViewModel(array('details'=>null,'longitude'=>0,'lattitude'=>0));
			else {
				$latlng = null;
				try{
				$latlng = $this->getLatLong($ret['details']['quartier'],$ret['details']['commune'],$ret['details']['wilaya']);
				}catch(\Exception $e){
					
				}
				if($latlng!=null) $viewModel = new ViewModel(array('details'=>$ret['details'],'longitude'=>$latlng['longitude'],'lattitude'=>$latlng['lattitude']));
				else $viewModel = new ViewModel(array('details'=>$ret['details'],'longitude'=>0,'lattitude'=>0));

			}
			return $viewModel;
	}
	public function communeAction(){
		$req = $this->getRequest();
		if ($req->isPost())
		{
			$wilaya = $req->getPost('wilaya');
			$communes = $this->getCommunes(strtolower($wilaya));
			return new JsonModel($communes);
		}
	}
	public function searchAction(){
		
		$req = $this->getRequest();
		if ($req->isPost())
		{
			$page = 1;			
			
			//les champs de filtre
			$text = $req->getPost('place');
			if($text!=''){
				$w = $this->extractWilaya($text);
				$wilaya = ($w!=null)?$w['corrected']:'';
				$c = $this->extractCommunes($text);
				$commune = ($c!=null)?$c['corrected']:'';
				if($w!=null){
					$text = str_replace($w['original'],"",$text);
					if($c!=null){
						$text = str_replace($c['original'],"",$text);
						$quartier = str_replace(",","",$text);
					}else $quartier = '';
				}else $quartier = '';


			}else{
				$wilaya = '';
				$commune = '';
				$quartier = '';
			}
			

			
			$type_annonce = strtolower($req->getPost('annonce'));
			$type_bien = strtolower($req->getPost('bien'));
			
			$last_request = array('annonce'=>$type_annonce,
								  'bien'=>$type_bien,
								  'wilaya'=>$wilaya,
								  'commune'=>$commune,
								  'quartier'=>$quartier,
								  'min'=>0,
								  'max'=>0
								  );

			
			
			//solliciter le service REST
			$request = new Request();
			$request->getHeaders()->addHeaders(array(
				'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
			));
			$request->setUri("http://darna.admin/services/getAnnonceBy?page=$page&annonce=$type_annonce&bien=$type_bien&quartier=$quartier&commune=$commune&wilaya=$wilaya");
			$request->setMethod('GET');
			
			$client = new Client();
			$response = $client->dispatch($request);
			$res = strstr($response->getContent(), '{');
			$res = substr($res, 0, strrpos( $res, '}')+1);
			$ret = json_decode($res, true);
			
			
			$type_annonce = $this->getAnnonceTypes();
			$type_bien = $this->getBienTypes();
			$wilaya = $this->getWilayas();
			
			$this->layout('layout/layout');
			if($ret['status']=='FAILURE') return new ViewModel(array('types'=>$type_annonce,'bien'=>$type_bien,'wilaya'=>$wilaya,'last_request'=>$last_request,'data'=>null));
			else return new ViewModel(array('types'=>$type_annonce,'bien'=>$type_bien,'wilaya'=>$wilaya, 'last_request'=>$last_request,'total'=>$ret['total'] ,'data'=>$ret['annonces']));
			
		}else{
			$last_request = array('annonce'=>'',
								  'bien'=>'',
								  'wilaya'=>'',
								  'commune'=>'',
								  'quartier'=>'',
								  'min'=>0,
								  'max'=>0
								  );
			
			$request = new Request();
			$request->getHeaders()->addHeaders(array(
				'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8'
			));
			$request->setUri("http://darna.admin/services/getAnnonceBy?page=1");
			$request->setMethod('GET');
			
			$client = new Client();
			$response = $client->dispatch($request);
			$res = strstr($response->getContent(), '{');
			$res = substr($res, 0, strrpos( $res, '}')+1);
			$ret = json_decode($res, true);
			
			
			$type_annonce = $this->getAnnonceTypes();
			$type_bien = $this->getBienTypes();
			$wilaya = $this->getWilayas();
			
			$this->layout('layout/layout');
			if($ret['status']=='FAILURE') return new ViewModel(array('types'=>$type_annonce,'bien'=>$type_bien,'wilaya'=>$wilaya,'last_request'=>$last_request,'data'=>null));
			else return new ViewModel(array('types'=>$type_annonce,'bien'=>$type_bien,'wilaya'=>$wilaya, 'total'=>$ret['total'] ,'last_request'=>$last_request,'data'=>$ret['annonces']));
		}
	}
	
	public function extractWilaya($text){
		$w = $this->getEntityManager()->createQuery("select w.nom from Administration\Model\Entity\Wilaya as w")->execute();
		$set = $this->explodeX(array(','),$text);
		foreach($set as $s){
			foreach($w as $i){
				if(levenshtein($i['nom'],$s)<=2) return array('corrected'=>$i['nom'],'original'=>$s);
			}
		}
		return null;
	}
	public function extractCommunes($text){
		$w = $this->getEntityManager()->createQuery("select w.nom from Administration\Model\Entity\Commune as w")->execute();
		$set = $this->explodeX(array(','),$text);
		foreach($set as $s){
			foreach($w as $i){
				if(levenshtein($i['nom'],$s)<=2) return array('corrected'=>$i['nom'],'original'=>$s);
			}
		}
		return null;
	}
	public function explodeX( $delimiters, $string )
	{
		return explode( chr( 1 ), str_replace( $delimiters, chr( 1 ), $string ) );
	}
	
	public function ajaxSearchAction(){
		
		$req = $this->getRequest();
		if ($req->isPost())
		{
			//page
			$page = $req->getPost('page');
			
			//les champs de filtre
			$wilaya = $req->getPost('wilaya');
			$commune = $req->getPost('commune');
			$quartier = $req->getPost('quartier');
			$type_annonce = strtolower($req->getPost('annonce'));
			$type_bien = strtolower($req->getPost('bien'));
			$min = strtolower($req->getPost('min'));
			$max = strtolower($req->getPost('max'));
			
			//echo "quartier:".$quartier;
			
			//solliciter le service REST
			$request = new Request();
			$request->getHeaders()->addHeaders(array(
				'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
			));
			$request->setUri("http://darna.admin/services/getAnnonceBy?page=$page&annonce=$type_annonce&bien=$type_bien&quartier=$quartier&commune=$commune&wilaya=$wilaya&min=$min&max=$max");
			$request->setMethod('GET');
			
			$client = new Client();
			$response = $client->dispatch($request);
			$res = strstr($response->getContent(), '{');
			$res = substr($res, 0, strrpos( $res, '}')+1);
			$ret = json_decode($res, true);
			
			
			$this->layout('layout/layout');
			if($ret['status']=='FAILURE') return new JsonModel(array('total'=>0,'data'=>null));
			else {
				return new JsonModel(array('total'=>$ret['total'] ,'data'=>$ret['annonces']));
			}
			
		}
	}
	
	public function detailsAction(){
				
		$req = $this->getRequest();
		if ($req->isPost())
		{
			//page
			$id = $req->getPost('id');
			
			//solliciter le service REST
			$request = new Request();
			$request->getHeaders()->addHeaders(array(
				'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
			));
			$request->setUri("http://darna.admin/services/getAnnonceDetails?id=$id");
			$request->setMethod('GET');
			
			$client = new Client();
			$response = $client->dispatch($request);
			$ret = json_decode($response->getContent(), true);
			
			
			$this->layout('layout/layout');
			if($ret['status']=='FAILURE') return new JsonModel(array('details'=>null,'longitude'=>0,'lattitude'=>0));
			else {
				$latlng = null;
				try{
				$latlng = $this->getLatLong($ret['details']['quartier'],$ret['details']['commune'],$ret['details']['wilaya']);
				}catch(\Exception $e){
					
				}
				if($latlng!=null) return new JsonModel(array('details'=>$ret['details'],'longitude'=>$latlng['longitude'],'lattitude'=>$latlng['lattitude']));
				else return new JsonModel(array('details'=>$ret['details'],'longitude'=>0,'lattitude'=>0));

			}
		}
	}
	
	public function getPositionAction(){
		$req = $this->getRequest();
		if ($req->isPost())
		{
			
			$quartier = $req->getPost('quartier');
			$commune = $req->getPost('commune');
			$wilaya = $req->getPost('wilaya');
			$latlng = null;
			try{
				$latlng = $this->getLatLong($quartier,$commune,$wilaya);
			}catch(\Exception $e){
					
			}
			if($latlng!=null) return new JsonModel(array('longitude'=>$latlng['longitude'],'lattitude'=>$latlng['lattitude']));
			else return new JsonModel(array('longitude'=>0,'lattitude'=>0));
		}
	}
	
	public function ChartDataAction(){
		$req = $this->getRequest();
		if ($req->isPost())
		{
			$data = $this->getChartData();	
			return new JsonModel(array('success'=>true,'data'=>$data));
			
		}
	}
	public function HeatDataAction(){
		$req = $this->getRequest();
		if ($req->isPost())
		{

			$type_annonce = strtolower($req->getPost('annonce'));
			$type_bien = strtolower($req->getPost('bien'));
			

			
			//solliciter le service REST
			$request = new Request();
			$request->getHeaders()->addHeaders(array(
				'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
			));
			$request->setUri("http://darna.admin/services/getAnnonceBy?page=0&annonce=$type_annonce&bien=$type_bien");
			$request->setMethod('GET');
			
			$client = new Client();
			$response = $client->dispatch($request);
			$res = strstr($response->getContent(), '{');
			$res = substr($res, 0, strrpos( $res, '}')+1);
			$ret = json_decode($res, true);
			
			
			$this->layout('layout/layout');
			if($ret['status']=='FAILURE') return new JsonModel(array('moyenne'=>0,'data'=>null));
			else {
				$prices = $this->getPrices($ret['annonces']);
				$average = $this->getAverage($prices);
				return new JsonModel(array('moyenne'=>(int)$average ,'data'=>$ret['annonces']));
			}
			
		}
	}
	public function getChartData(){
		$wilayas = $this->getWilayas();
		$ret = array();
		$ret[] = array('State','Moyenne du m²');
		foreach($wilayas as $wilaya){
			
			$prices = $this->getWilayaPrices($wilaya['id']);
			$prix = array();
			foreach($prices as $item){
				$prix[] = (int) $item['moyenne'];
			}
			if(count($prix)>0) $average = (int) $this->getAverage($prix);
			else $average = 0;
			$ret[] = array(strtolower($wilaya['nom']),$average);
		}
		return $ret;
	}

	public function getLatLong($quarier,$commune,$wilaya){
		
		$adresse = '';

		if($quarier!='' && $quarier!='Inconnue'){
			$adresse = $adresse . $quarier . ',';
			
		}
		if($commune!='' && $commune!='Inconnue'){
			$adresse = $adresse . $commune . ',';
		}
		if($wilaya!='' && $wilaya!='Inconnue'){
			$adresse = $adresse . $wilaya . ',';
		}
		
		if($adresse!=''){
			$adresse = $adresse . 'algerie';
			$geo = $this->geocode($adresse);

			if($geo != null){
				return array('longitude'=>$geo['lng'],
							 'lattitude'=>$geo['lat']);
			}else return null;
		}
	}
	
	function google_geocoding($addr){
		$key = "AIzaSyAmtSnnoIsLH5gFTjZtk0_sBcDe1C2KX8c";
		$url = "https://maps.google.com/maps/api/geocode/json?address=".urlencode($addr)."&key=$key&sensor=false";
		$json_txt = file_get_contents($url);
		if (! $json_txt)
			return null;
		$json_arr = json_decode($json_txt, TRUE);
		if ($json_arr["status"] != "OK")
			return null;
	 
		$result = $json_arr["results"][0];
		$ret = array(
			"addr" => $addr,
			"faddr" => $result["formatted_address"],
			"lat" => $result["geometry"]["location"]["lat"], 
			"lng" => $result["geometry"]["location"]["lng"]
		);
		return $ret; 
	}
	function geocode($addr){
		$addr = trim(strtolower($addr));
	 
		// Recherche dans le cache cache
		$ret = $this->checkInCache($addr);
		if($ret != null){
			return array(
				"addr" => $ret['addr'],
				"faddr" => $ret['faddr'],
				"lat" => $ret['lat'], 
				"lng" => $ret['lng']
			);
		}
	 
		// Solliciter le service Google géocoding et mettre à jour le cache
		$ret = $this->google_geocoding($addr);
		if($ret == null) return null;
		$this->updateCache($ret['addr'],$ret['faddr'],$ret['lat'],$ret['lng']);
		return $ret; 
	}
	
	public function preEstimateAction(){
		$req = $this->getRequest();
		if ($req->isPost()){
			$wilaya = $req->getPost('wilaya');
			$commune = $req->getPost('commune');
			$superficie = $req->getPost('superficie');
			
			$estimation = (int)$this->getEstimation($commune);

			if($estimation!=0){
				$estimation *= (int) $superficie;
				$ret = array('success'=>true,
							 'estimation'=>$estimation,
							 );
			}else{
				$ret = array('success'=>false,
							 'errorMessage'=>"Désolé nous n'avons pas pu estimer votre bien dans cette commune"
							 );
			}
			return new JsonModel($ret);

		}
	}
	public function ajaxEstimateAction(){
		$req = $this->getRequest();
		if ($req->isPost())
		{
			//page
			$wilaya = $req->getPost('wilaya');
			$annonce = $req->getPost('annonce');
			$bien = $req->getPost('bien');
			if($bien == 'appartement') $pieces = $req->getPost('pieces');
			else $pieces = '';
			
			//solliciter le service REST
			$request = new Request();
			$request->getHeaders()->addHeaders(array(
				'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8',
			));
			$request->setUri("http://darna.admin/services/getAnnonceBy?page=0&annonce=$annonce&bien=$bien");
			$request->setMethod('GET');
			
			$client = new Client();
			$response = $client->dispatch($request);
			$res = strstr($response->getContent(), '{');
			$res = substr($res, 0, strrpos( $res, '}')+1);
			$ret = json_decode($res, true);
			$ret = $ret['annonces'];
			
			if($pieces!='') $ret = $this->filtrePieces($ret,$pieces);
			$moy_wil = $this->moyenneWilaya($ret,$wilaya);
			$moy_nat = $this->moyenneNationale($ret);
			$ret = 0;
			if($moy_wil==0){
				$ret = (int)$moy_nat;
			}else{
				$poid_wil = $this->getPoidWilaya($moy_wil,$moy_nat);
				$ret = (int)($poid_wil*$moy_wil+(1-$poid_wil)*$moy_nat);
			}
			$ret = $this->arondissement($ret);
			return new JsonModel(array('estimation'=>$ret,'moyenne_nat'=>(int)$moy_nat,'moyenne_wil'=>(int)$moy_wil));
		}
	}
	
	public function arondissement($price){
		$len = strlen((string)$price);
		$ret = $price / pow(10,($len-1));
		if($len<=3) $ret = ($this->round_up($ret,1))* pow(10,($len-1));
		else if(3<$len && $len<=6) $ret = ($this->round_up($ret,2))* pow(10,($len-1));
		else if(6<$len && $len<=9) $ret = ($this->round_up($ret,3))* pow(10,($len-1));
		else if(9<$len) $ret = ($this->round_up($ret,4))* pow(10,($len-1));
		else $ret = ($this->round_up($ret,2))* pow(10,($len-1));
		return (int) $ret;
	}
	
	function round_up ( $value, $precision ) { 
		$pow = pow ( 10, $precision ); 
		return ( ceil ( $pow * $value ) + ceil ( $pow * $value - ceil ( $pow * $value ) ) ) / $pow; 
	}
	
	public function filtrePieces($annonces,$pieces){
		$ret = array();
		foreach($annonces as $annonce){
			if($annonce['pieces']==$pieces) $ret[] = $annonce;
		}
		return $ret;
	}
	public function moyenneWilaya($annonces,$wilaya){
		$prices = array();
		foreach($annonces as $annonce){
			if($annonce['prix']!='0' && $annonce['wilaya']==$wilaya){
				$prices[] = (int) $annonce['prix'];
			}
		}
		return $this->getAverage($prices);
	}
	public function moyenneNationale($annonces){
		$prices = array();
		foreach($annonces as $annonce){
			if($annonce['prix']!='0'){
				$prices[] = (int) $annonce['prix'];
			}
		}
		return $this->getAverage($prices);;
	}
	public function getPrices($annonces){
		$prices = array();
		foreach($annonces as $annonce){
			if($annonce['prix']!='0'){
				$prices[] = (int) $annonce['prix'];
			}
		}
		return $prices;
	}
	public function getAverage($prices){
		if(count($prices)>0) return (int) array_sum($prices)/count($prices);
		else return 0;
	}
	public function getPoidWilaya($moy_wil,$moy_nat){
		if($moy_wil<$moy_nat){
			return (($moy_wil)/$moy_nat);
		}else{
			return (1-(($moy_nat)/$moy_wil));
		}
	}
	
    	
	    /**
	    * @return EntityManager
	    */
	public function getEntityManager()
	{
		return $this
					->getServiceLocator()
					->get('Doctrine\ORM\EntityManager');
	
	}
	public function getCommunes($wilaya){
		$code = $this->getEntityManager()->createQuery("select w.code from Administration\Model\Entity\Wilaya as w where LOWER(w.nom)='$wilaya'")->execute()[0]['code'];
		return $this->getEntityManager()->createQuery("select c.nom from Administration\Model\Entity\Commune as c where c.wilaya_id='".$code."'")->execute();
	}
	public function getWilayas(){
		return $this->getEntityManager()->createQuery("select w.nom,w.id from Administration\Model\Entity\Wilaya as w")->execute();
	}
	public function getAllCommunes(){
		return $this->getEntityManager()->createQuery("select c.nom from Administration\Model\Entity\Commune as c")->execute();
	}
	public function getAnnonceTypes(){
		return $this->getEntityManager()->createQuery("select t.type from Administration\Model\Entity\Type as t where t.cat='annonce'")->execute();
	}
	public function getBienTypes(){
		return $this->getEntityManager()->createQuery("select t.type from Administration\Model\Entity\Type as t where t.cat='bien'")->execute();
	}
	public function checkInCache($addr){
		$req = $this->getEntityManager()->createQuery("select c.addr, c.faddr,c.lat, c.lng from Administration\Model\Entity\Cache as c
													  where c.addr='$addr'")->execute();
		return (count($req)>0?$req[0]:null);
	}
	public function getWilayaPrices($id){
		return $this->getEntityManager()->createQuery("select p.moyenne from Administration\Model\Entity\Moyenne as p,
											  Administration\Model\Entity\Commune as c
											where p.commune=c.id and c.wilaya_id='$id'")->execute();
	}
	public function getEstimation($commune){
		$id_commune = $this->getEntityManager()->createQuery("select c.id from Administration\Model\Entity\Commune as c where c.nom='$commune'")->execute();
		$id = (count($id_commune)>0)?$id_commune[0]['id']:null;
		if($id==null) return 0;
		$val =  $this->getEntityManager()->createQuery("select m.moyenne from Administration\Model\Entity\Moyenne as m where m.commune='$id'")->execute();
		return (count($val)>0)?$val[0]['moyenne']:0;
	}

	public function updateCache($addr,$faddr,$lat,$lng){
		$cache = new Cache();
		$cache->__set("addr",$addr);
		$cache->__set("faddr",$faddr);
		$cache->__set("lat",$lat);
		$cache->__set("lng",$lng);
		try{
			$this->getEntityManager()->persist($cache);
			$this->getEntityManager()->flush($cache);
		}catch(\Exception $e){
			echo $e->getMessage();
			$e->getMessage();
		}
	}
}
