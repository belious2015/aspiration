<?php

namespace Administration\Form;

use Zend\InputFilter\InputFilter;
use Zend\Validator\Db\NoRecordExists;

class AddUserFilter extends InputFilter {
	public function __construct($sm) {
		$this->add ( array (
			'name' => 'id_user',
					'required' => true,
					'filters' => array (
							array (
									'name' => 'Int' 
							) 
					) 
		) );
		

		$this->add ( array (
				'name' => 'nom_user',
				'required' => false,
				'filters' => array (
						array (
								'name' => 'StripTags'
						),
						array (
								'name' => 'StringTrim'
						)
				),
				'validators' => array (
						array (
								'name' => 'StringLength',
								'options' => array (
										'encoding' => 'UTF-8',
										'min' => 5,
										'max' => 20
								)
						)
				)
		)  );
			
		$this->add ( array (
				'name' => 'prenom_user',
				'required' => false,
				'filters' => array (
						array (
								'name' => 'StripTags'
						),
						array (
								'name' => 'StringTrim'
						)
				),
				'validators' => array (
						array (
								'name' => 'StringLength',
								'options' => array (
										'encoding' => 'UTF-8',
										'min' => 5,
										'max' => 15
								)
						)
				)
		)  );
			
			
		$this->add (array (
				'name' => 'adress_user',
				'required' => false
		)  );
		$this->add (  array (
				'name' => 'pass_user',
				'required' => false
		)  );
		$this->add (  array (
				'name' => 'organisme_user',
				'required' => false
		)  );
		$this->add ( array (
				'name' => 'fonction_user',
				'required' => false
		)  );
		$this->add (  array (
				'name' => 'mail_user',
				'required' => false,
				'validators' => array(
						array(
								'name'    => 'StringLength',
								'options' => array(
										'encoding' => 'UTF-8',
										'min'      => 10,
										'max'     => 25
								),
						),
						array(
								'name'    => 'Zend\Validator\Db\NoRecordExists',
								'options' => array(
										'table' => 'users',
										'field' => 'mail_user',
										'adapter' =>  $sm->get ( 'Zend\Db\Adapter\Adapter' ),
										'messages' => array(
										NoRecordExists::ERROR_RECORD_FOUND => 'Adresse e-mail déjà utilisée'
										),
								),
						),
				),
		
		)
		
		);
		
		$this->add (  array (
				'name' => 'userName_user',
				'required' => false,
				'validators' => array(
						array(
								'name'    => 'StringLength',
								'options' => array(
										'encoding' => 'UTF-8',
										'min'      => 2,
										'max'     => 25
								),
						),
						array(
								'name'    => 'Zend\Validator\Db\NoRecordExists',
								'options' => array(
										'table' => 'users',
										'field' => 'username_user',
										'adapter' =>  $sm->get ( 'Zend\Db\Adapter\Adapter' ),
										'messages' => array(
												NoRecordExists::ERROR_RECORD_FOUND => 'Nom d\'utilisateur déjà pris'
										),
								),
						),
				),
		
		)
		
		);
	}
}

?>