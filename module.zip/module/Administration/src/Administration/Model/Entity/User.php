<?php
namespace Administration\Model\Entity;
use Doctrine\ORM\Mapping as ORM;


/**
 * User.
 *
 * @ORM\Entity
 * @ORM\Table(name="users")
 * @property string $user_name
 * @property string $passwd
 * @property string $email
 */
class User{
	/**
	 * @ORM\Id
	 * @ORM\Column (type="string",columnDefinition="VARCHAR(45)")
	 */
	protected $user_name;

	/**
	 * @ORM\Id
	 * @ORM\Column (type="string",columnDefinition="VARCHAR(200)")
	 */
	protected $passwd;
	
	/**
	 * @ORM\Column (type="string",columnDefinition="VARCHAR(100)")
	 */
	protected $email;
	
	/**
	 * @return the $passwd
	 */
	public function getPasswd() {
		return $this->passwd;
	}

	/**
	 * @return the $user_name
	 */
	public function getUser_name() {
		return $this->user_name;
	}
	
	/**
	 * @return the $email
	 */
	public function getEmail() {
		return $this->email;
	}

	/**
	 * @param field_type $passwd
	 */
	public function setPasswd($passwd) {
		$this->passwd = $passwd;
	}

	/**
	 * @param field_type $user_name
	 */
	public function setUser_name($user_name) {
		$this->user_name = $user_name;
	}
	
	/**
	 * @param field_type $passwd
	 */
	public function setEmail($email) {
		$this->email = $email;
	}

	

	public static function getAll($entityManager){
		return $entityManager->createQuery("SELECT u FROM Administration\Model\Entity\User u")->execute();
	}
	
	/**
	 * Pour l'authentification
	 * @param User  $user
	 * @param string $password
	 * @return boolean
	 */
	public static function hashPassword($user, $password)
	{
		return ($user->getPasswd() === MD5('aFGQ475SDsdfsaf2342'.$password));
	}
	
}


?>
