<?php
namespace Administration\Model\Entity;
use Doctrine\ORM\Mapping as ORM;


/**
 * Moyenne.
 *
 * @ORM\Entity
 * @ORM\Table(name="prix")
 * @property integer $id
 * @property string $commune
 * @property string $moyenne
 */
class Moyenne{
	/**
	 * @ORM\Id
	 * @ORM\Column (type="integer",columnDefinition="INT(11)")
	 * @ORM\GeneratedValue(strategy="AUTO")
	 */
	protected $id;

	/**
	 * @ORM\Column (type="integer")
	 */
	protected $commune;
	
	/**
	 * @ORM\Column (type="string")
	 */
	protected $moyenne;
	
    /**
     * Magic getter to expose protected properties.
     *
     * @param string $property
     * @return mixed
     */
    public function __get($property) 
    {
        return $this->$property;
    }
  
    /**
     * Magic setter to save protected properties.
     *
     * @param string $property
     * @param mixed $value
     */
    public function __set($property, $value) 
    {
        $this->$property = $value;
    }
	
}


?>
