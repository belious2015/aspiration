<?php
namespace Administration\Model\Entity;
use Doctrine\ORM\Mapping as ORM;


/**
 * Type.
 *
 * @ORM\Entity
 * @ORM\Table(name="type")
 * @property integer $id
 * @property string $cat
 * @property string $type
 */
class Type{
	/**
	 * @ORM\Id
	 * @ORM\Column (type="string")
	 */
	protected $id;

	/**
	 * @ORM\Id
	 * @ORM\Column (type="string",columnDefinition="VARCHAR(45)")
	 */
	protected $cat;
	
	/**
	 * @ORM\Column (type="string",columnDefinition="VARCHAR(45)")
	 */
	protected $type;
	
	    /**
     * @param string $property
     * @return mixed
     */
    public function __get($property) 
    {
        return $this->$property;
    }
  
    /**
     * @param string $property
     * @param mixed $value
     */
    public function __set($property, $value) 
    {
        $this->$property = $value;
    }
	
}


?>
