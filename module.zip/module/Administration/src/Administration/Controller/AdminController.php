<?php
namespace Administration\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;


class AdminController extends AbstractActionController
{
	
	public function indexAction()
		{
			$auth = $this->getServiceLocator()->get('Zend\Authentication\AuthenticationService');
			if ($auth->hasIdentity()) {
				$identity = $auth->getIdentity();
			}else{
				return $this->redirect()->toRoute('admin',array('controller'=>'auth', 'action'=>'login'));	
			}
			$this->layout('layout/admin-layout');
			$this->layout()->setVariable('user', $identity->getUser_name());
			return new ViewModel();
		}


	
}


