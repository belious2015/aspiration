<?php
namespace Administration\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;
use Administration\Model\Entity\Spider;
use Doctrine\ORM\EntityManager;
use Zend\ServiceManager\Exception;


class SpiderController extends AbstractActionController
{

/********************************************************** Controller actions *********************************************************/

	public function listAction()
		{
			$auth = $this->getServiceLocator()->get('Zend\Authentication\AuthenticationService');
			if ($auth->hasIdentity()) {
				$identity = $auth->getIdentity();
			}else{
				return $this->redirect()->toRoute('admin',array('controller'=>'auth', 'action'=>'login'));	
			}
			
			$this->layout('layout/admin-layout');
			$this->layout()->setVariable('user', $identity->getUser_name());
			$spidersD = $this->getSpiders();
			//il faut vérifier l'état de chaque spider
			$projets = $this->getProjects();
			$spiders = array();
			foreach($projets as $projet){
				$spiders = array_merge($spiders,$this->getSpidersInfo($projet['design']));
			}
			$spidersD = $this->removeDeployed($spidersD,$spiders);
			$spiders = array_merge($spiders,$spidersD);
			return new ViewModel(array('spiders'=>$spiders));
		}

	public function addAction()
		{
			$auth = $this->getServiceLocator()->get('Zend\Authentication\AuthenticationService');
			if ($auth->hasIdentity()) {
				$identity = $auth->getIdentity();
			}else{
				return $this->redirect()->toRoute('admin',array('controller'=>'auth', 'action'=>'login'));	
			}
			
			$this->layout('layout/admin-layout');
			$this->layout()->setVariable('user', $identity->getUser_name());
			$prj = $this->getProjects();
			return new ViewModel(array('projets'=>$prj));
		}
	public function editAction()
		{
			$auth = $this->getServiceLocator()->get('Zend\Authentication\AuthenticationService');
			if ($auth->hasIdentity()) {
				$identity = $auth->getIdentity();
			}else{
				return $this->redirect()->toRoute('admin',array('controller'=>'auth', 'action'=>'login'));	
			}
			
			$this->layout('layout/admin-layout');
			$this->layout()->setVariable('user', $identity->getUser_name());
			$spiders = $this->getSpidersID();
			
			return new ViewModel(array('spiders'=>$spiders));
		}
	public function pipelineAction()
		 {
			$auth = $this->getServiceLocator()->get('Zend\Authentication\AuthenticationService');
			if ($auth->hasIdentity()) {
				$identity = $auth->getIdentity();
			}else{
				return $this->redirect()->toRoute('admin',array('controller'=>'auth', 'action'=>'login'));	
			}
			
			$this->layout('layout/admin-layout');
			$this->layout()->setVariable('user', $identity->getUser_name());
			$projets = $this->getProjects();
			
			return new ViewModel(array('projets'=>$projets));
		 }
	public function itemAction()
		 {
			$auth = $this->getServiceLocator()->get('Zend\Authentication\AuthenticationService');
			if ($auth->hasIdentity()) {
				$identity = $auth->getIdentity();
			}else{
				return $this->redirect()->toRoute('admin',array('controller'=>'auth', 'action'=>'login'));	
			}
			
			$this->layout('layout/admin-layout');
			$this->layout()->setVariable('user', $identity->getUser_name());
			$projets = $this->getProjects();
			
			return new ViewModel(array('projets'=>$projets));
		 }
	public function settingsAction()
		 {
			$auth = $this->getServiceLocator()->get('Zend\Authentication\AuthenticationService');
			if ($auth->hasIdentity()) {
				$identity = $auth->getIdentity();
			}else{
				return $this->redirect()->toRoute('admin',array('controller'=>'auth', 'action'=>'login'));	
			}
			
			$this->layout('layout/admin-layout');
			$this->layout()->setVariable('user', $identity->getUser_name());
			$projets = $this->getProjects();
			
			return new ViewModel(array('projets'=>$projets));
		 }
	public function executeAction(){
		$config = $this->getServiceLocator()->get('Config');
		$scrapyd = $config['scrapyd']['host'];
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$spider = $request->getPost('spider');
			$projet = $request->getPost('projet');
			//il faut verifier que le job n'est pas en cours d'execution
			if(!$this->isJobRunning($projet,$spider)){
				$params = array(
					"project" => $projet,
					"spider" => $spider
				 );
				$output = $this->httpPost($scrapyd."schedule.json ",$params);
				$json_arr = json_decode($output, TRUE);
				if ($json_arr["status"] == "ok") {
					$ret = array('success'=>true, 'jobid'=>$json_arr["jobid"]);
				}
				else $ret = array('success'=>false);
			return new JsonModel($ret);
			}else return new JsonModel(array('success'=>false));
		}
	}
	
	public function stopAction(){
		$config = $this->getServiceLocator()->get('Config');
		$scrapyd = $config['scrapyd']['host'];
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$spider = $request->getPost('spider');
			$projet = $request->getPost('projet');
			$jobs = $this->getListJobs($projet);
			$id = $this->getSpiderStatus($jobs,$spider)['id'];
			if($id != ''){
			
				$params = array(
					"project" => $projet,
					"job" => $id
				 );
				do{
				$output = $this->httpPost($scrapyd."cancel.json ",$params);
				//echo "output: ".$output." ";
				$json_arr = json_decode($output, TRUE);
				}while($json_arr["prevstate"] != null);
				
				if ($json_arr["status"] == "ok") {
					$ret = array('success'=>true);
				}
				else $ret = array('success'=>false);
			}else $ret = array('success'=>false);
			return new JsonModel($ret);
		}
	}


	public function removeSpiderAction(){
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$spider = $request->getPost('spider');
			$projet = $request->getPost('projet');
			$path = $this->getPath($projet)[0]['path'];
			$path1 = $path."/".$projet."/spiders/".$spider.".py";
			$path2 = $path."/".$projet."/spiders/".$spider.".pyc";
			try{

				if (file_exists($path1)) {
					unlink($path1);
			    	}
				if (file_exists($path2)) {
					unlink($path2);
			    	}
				$this->deleteSpider($spider);
			}catch(\Exception $e){
				echo $e->getMessage();
			}
			
		}
	}

	public function ajouterSpiderAction(){  
		if ($_SERVER['REQUEST_METHOD'] == 'POST'){
			$success = false;
		   if(isset($_POST['projet']) & isset($_POST['nom']) & isset($_POST['domaine']) & isset($_POST['code'])){
			$success = true;		
			$path = $this->getPath($_POST['projet'])[0]['path'];
			$path = $path."/".$_POST['projet']."/spiders/";
			$content = strip_tags($_POST['code']);
			$fp = fopen($path.$_POST['nom'].".py","wb");
			fwrite($fp,$content);
			fclose($fp);
			shell_exec(escapeshellcmd("chmod 777 -R ".$path.$_POST['nom'].".py"));
			$spider = new Spider();
			$spider->__set("nom",$_POST['nom']);
			$id = $this->getID($_POST['projet'])[0]['id_projet'];
			$spider->__set("id_projet",$id);
			$spider->__set("domaine",$_POST['domaine']);
			try{
				$this->getEntityManager()->persist($spider);
				$this->getEntityManager()->flush($spider);
			}catch(\Exception $e){
				$e->getMessage();
				
			}
 		   }
			$this->layout('layout/admin-layout');
		    	return new ViewModel(array('success'=>$success,'nom' => $_POST['nom'] ,'output' => $content));
		}
	 }

	public function spiderDetailsAction(){
		$request = $this->getRequest();
		if ($request->isPost())
		{
			
			$spider = $request->getPost('spider');
			$projet = $this->getDesign($request->getPost('projet'))[0]['design'];
			$path = $this->getPath($projet)[0]['path'];
			$path = $path."/".$projet."/spiders/".$spider.".py";
			
			if($this->getSpider($spider)!=null){
				$sp = $this->getSpider($spider);
			}
			$id = $this->getSpider($spider)[0]['id_spider'];
			$nom = $sp[0]['nom'];
			$domaine = $sp[0]['domaine'];
			$code = $this->getCode($path);
			$data = new JsonModel(array(
					'success' => true,
					'nom' => $nom,
					'domaine' => $domaine,
					'code'=> $code,
					'projet' => $projet,
					'id' => $id
					
			));
			return $data;
			
		}

	}
	public function modifierSpiderAction(){
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$nom = $request->getPost('spider');
			$id_spider = $request->getPost('id');
			$projet = $request->getPost('projet');
			$domaine = $request->getPost('domaine');
			$code = $request->getPost('code');

			$path = $this->getPath($projet)[0]['path'];
			$path .="/".$projet."/spiders/".$nom.".py";

			$this->updateFile($path,$code);
			$this->updateSpider($id_spider,$nom,$domaine);
			/*<?php echo $this->url("admin", array("controller"=>"spider", "action"=>"modifier_spider")) ?>*/
			return $this->redirect()->toRoute('admin',
							array('controller'=>'spider',
								  'action' => 'list'));
			
		}
	}
	
	public function settingsDetailsAction(){
			$request = $this->getRequest();
			if ($request->isPost())
			{
				
				$prj_id = $request->getPost('projet');
				$projet = $this->getDesign($prj_id)[0]['design'];
				$path = $this->getPath($projet)[0]['path'];
				$path = $path."/".$projet."/settings.py";

				
	
				$code = $this->getCode($path);
				$data = new JsonModel(array(
						'success' => true,
						'path' => $path,
						'code'=> $code,
						'projet' => $projet,
						'id' => $prj_id
						
				));
				return $data;
				
			}

	}
	public function itemsDetailsAction(){
			$request = $this->getRequest();
			if ($request->isPost())
			{
				
				$prj_id = $request->getPost('projet');
				$projet = $this->getDesign($prj_id)[0]['design'];
				$path = $this->getPath($projet)[0]['path'];
				$path = $path."/".$projet."/items.py";

				
	
				$code = $this->getCode($path);
				$data = new JsonModel(array(
						'success' => true,
						'path' => $path,
						'code'=> $code,
						'projet' => $projet,
						'id' => $prj_id
						
				));
				return $data;
				
			}

	}
	public function pipelinesDetailsAction(){
			$request = $this->getRequest();
			if ($request->isPost())
			{
				
				$prj_id = $request->getPost('projet');
				$projet = $this->getDesign($prj_id)[0]['design'];
				$path = $this->getPath($projet)[0]['path'];
				$path = $path."/".$projet."/pipelines.py";

				
	
				$code = $this->getCode($path);
				$data = new JsonModel(array(
						'success' => true,
						'path' => $path,
						'code'=> $code,
						'projet' => $projet,
						'id' => $prj_id
						
				));
				return $data;
				
			}

	}
	public function modifierSettingsAction(){
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$projet = $request->getPost('projet');
			$code = $request->getPost('code');

			$path = $this->getPath($projet)[0]['path'];
			$path .="/".$projet."/settings.py";

			$this->updateFile($path,$code);

			return $this->redirect()->toRoute('admin',
							array('controller'=>'spider',
								  'action' => 'list'));
			
		}
	}
	public function modifierItemsAction(){
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$projet = $request->getPost('projet');
			$code = $request->getPost('code');

			$path = $this->getPath($projet)[0]['path'];
			$path .="/".$projet."/items.py";

			$this->updateFile($path,$code);
			return $this->redirect()->toRoute('admin',
							array('controller'=>'spider',
								  'action' => 'list'));
			
		}
	}
	public function modifierPipelinesAction(){
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$projet = $request->getPost('projet');
			$code = $request->getPost('code');

			$path = $this->getPath($projet)[0]['path'];
			$path .="/".$projet."/pipelines.py";

			$this->updateFile($path,$code);

			return $this->redirect()->toRoute('admin',
							array('controller'=>'spider',
								  'action' => 'list'));
			
		}
	}
	public function refreshStatusAction(){
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$spidersD = $this->getSpiders();
			$projets = $this->getProjects();
			$spiders = array();
			foreach($projets as $projet){
				$spiders = array_merge($spiders,$this->getSpidersInfo($projet['design']));
			}
			$spidersD = $this->removeDeployed($spidersD,$spiders);
			$spiders = array_merge($spiders,$spidersD);
			if(count($spiders)>0) return new JsonModel(array('success'=>true,'spiders'=>$spiders));
			else return new JsonModel(array('success'=>false));
			
		}
	}

	public function updateFile($path, $code){
			$code = strip_tags($code);
			$fp = fopen($path,"wb");
			fwrite($fp,$code);
			fclose($fp);
	}
	public function getCode($path){
		$fh = fopen($path, "rb");
		$data = fread($fh, filesize($path));
		fclose($fh);
		return $data;
	}

	public function httpPost($url,$params){
	  $postData = '';
	   //create name value pairs seperated by &
	   foreach($params as $k => $v) 
	   { 
		  $postData .= $k . '='.$v.'&'; 
	   }
	   $postData = rtrim($postData, '&');
	 
		$ch = curl_init();  
	 
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_HEADER, false); 
		curl_setopt($ch, CURLOPT_POST, count($postData));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
	 
		$output=curl_exec($ch);
	 
		curl_close($ch);
		return $output; 
	}
	public function httpGet($url){
		$ch = curl_init();  
	 
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	//  curl_setopt($ch,CURLOPT_HEADER, false); 
	 
		$output=curl_exec($ch);
	 
		curl_close($ch);
		return $output;
	}
	
	public function removeDeployed($spidersD,$spiders){
		$ret = array();
		$cpt = count($spidersD);
		for($i=0;$i<$cpt;$i++){
			if(!$this->spiderExist($spiders,$spidersD[$i]['nom'],$spidersD[$i]['design'])){
				$ret[] = array('projet'=> $spidersD[$i]['design'],
							   'spider' => $spidersD[$i]['nom'],
							   'status' => 'nondeployed',
							   'id' => '');
			}
		}
		return $ret;
	}
	
	public function spiderExist($tab, $spider, $projet){
		foreach($tab as $item){
			if($item['projet']==$projet && $item['spider']==$spider) return true;
		}
		return false;
	}

	public function getSpidersInfo($project){
		$config = $this->getServiceLocator()->get('Config');
		$scrapyd = $config['scrapyd']['host'];
		$output = $this->httpGet($scrapyd."listspiders.json?project=".$project);
		$json_arr = json_decode($output, TRUE);
		$ret = array();
		$jobs = $this->getListJobs($project);
		if ($json_arr["status"] == "ok") {
			foreach($json_arr["spiders"] as $spider){
				$status = $this->getSpiderStatus($jobs,$spider);
				$ret[] = array('projet'=>$project,
								'spider'=>$spider,
								'status'=>$status['status'],
								'id'=>$status['id']);
			}
		}
		return $ret;
	}
	public function getSpiderStatus($projetJobs, $spider){
		$ret = array();
		$ret['status']='stopped';
		$ret['id'] = '';
		foreach($projetJobs['running'] as $job){
			if($job['spider']==$spider){
				$ret['status']='running';
				$ret['id'] = $job['id'];
				break;
			}
		}
		return $ret;
	}
	public function getListJobs($project){
		$config = $this->getServiceLocator()->get('Config');
		$scrapyd = $config['scrapyd']['host'];
		$output = $this->httpGet($scrapyd."listjobs.json?project=".$project);
		return json_decode($output, TRUE);
	}
	public function isJobRunning($projet,$spider){
		$jobs = $this->getListJobs($projet);
		$status = $this->getSpiderStatus($jobs,$spider);
		if($status['status']=='running') return true;
		else return false;
	}

/*********************************************************** Database actions **************************************************************/


	    /**
	    * @return EntityManager
	    */
	public function getEntityManager()
	{
		return $this
					->getServiceLocator()
					->get('Doctrine\ORM\EntityManager');
	
	}

	public function getProjects(){
        	$ret = $this->getEntityManager()->createQuery("select p.id_projet,p.design from Administration\Model\Entity\Projet as p")->execute();
		return ((count($ret)>0) ? $ret :null);
	}

	public function getSpiders(){
        	$ret = $this->getEntityManager()->createQuery("select s.nom,p.design from Administration\Model\Entity\Projet as p,
											  Administration\Model\Entity\Spider as s
											where p.id_projet=s.id_projet")->execute();
		return ((count($ret)>0) ? $ret :null);
	}
	public function getSpidersID(){
        	$ret = $this->getEntityManager()->createQuery("select s.id_spider,s.nom,p.id_projet from Administration\Model\Entity\Projet as p,
											  Administration\Model\Entity\Spider as s
											where p.id_projet=s.id_projet")->execute();
		return ((count($ret)>0) ? $ret :null);
	}

	public function deleteSpider($nom){
		$ret = $this->getEntityManager()->createQuery("delete from Administration\Model\Entity\Spider as s where s.nom='$nom'")->execute();
		return ((count($ret)>0) ? $ret :null);	
	}

	public function getPath($projet){
		$ret = $this->getEntityManager()->createQuery("select p.path from Administration\Model\Entity\Projet as p where p.design='$projet'")->execute();
		return ((count($ret)>0) ? $ret :null);	
	}
	public function getDesign($projet){
		$ret = $this->getEntityManager()->createQuery("select p.design from Administration\Model\Entity\Projet as p where p.id_projet='$projet'")->execute();	
		return ((count($ret)>0) ? $ret :null);
	}

	public function getID($projet){
		$ret = $this->getEntityManager()->createQuery("select p.id_projet from Administration\Model\Entity\Projet as p where p.design='$projet'")->execute();
		return ((count($ret)>0) ? $ret :null);	
	}

	public function getSpider($name){
        	$ret = $this->getEntityManager()->createQuery("select s.id_spider,s.nom, s.domaine from Administration\Model\Entity\Spider as s
									where s.nom='$name'")->execute();
		return ((count($ret)>0) ? $ret :null);
	}

	public function updateSpider($id, $name, $domaine){
        	$this->getEntityManager()->createQuery("update Administration\Model\Entity\Spider as s
									set s.nom='$name', s.domaine='$domaine' where s.id_spider='$id'")->execute();
	}


	
}


