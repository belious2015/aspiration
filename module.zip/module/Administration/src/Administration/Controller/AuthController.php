<?php
/**
 * Class AuthController
 * Fichier Module.php, Module Administration
 * @author Djenane Lyes
 * Date : 23/02/2016
 */

namespace Administration\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Authentication\Result;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;
use Administration\Form\AuthForm;
use Zend\Mail\Message;
use Zend\Authentication\AuthenticationService;
use Zend\Exception;

class AuthController extends AbstractActionController {

	
	
	public function loginajaxAction(){		
		
		$login = $this->getRequest()->getPost('login');
		$login = json_decode($login);

		$staticSalt = $this->getStaticSalt();
	
		$auth = $this->getServiceLocator()->get('Zend\Authentication\AuthenticationService');

		$auth->getAdapter()->setIdentityValue($login->name);

		$auth->getAdapter()->setCredentialValue($login->pass);

		$result = $auth->authenticate();
		
		if ($result->isValid()) {
				$time = 1209600; // 14 days 1209600/3600 = 336 hours => 336/24 = 14 days
				if ($login->rememberme) {
					$sessionManager = new \Zend\Session\SessionManager();
					$sessionManager->rememberMe($time);
				}
				$data = new JsonModel(array(
						'success' => true,
						'results' => 'Admin',
				));	
		}else{
				$messages = "Nom d'utilisateur ou mot de passe incorrect !";
				$data = new JsonModel(array(
						'success' => false,
						'results' => $messages,
				));
		}
		return $data;

	}
	
	
	
	
	
	public function loginAction()
		{
			
		$form = new AuthForm();	
		$viewModel = new ViewModel(array('form'=>$form));
		$viewModel->setTerminal(true);
		return $viewModel;
	    }
	
	public function testAction(){
		echo 'test';
	}
	
	
	public function logoutAction()
		{
			$sm = $this->getServiceLocator();
			$auth = $sm->get('Zend\Authentication\AuthenticationService');
			
			if ($auth->hasIdentity()) {
				$identity = $auth->getIdentity();
			}			
			
			$auth->clearIdentity();
			//$sessionManager = new \Zend\Session\SessionManager();
			//$sessionManager->forgetMe();
			
			return $this->redirect()->toRoute('admin',array('controller'=>'auth', 'action'=>'login'));		
		}

			
			
	public function forgottenPasswordAction()
		{
			$user=$this->getRequest()->getPost('user');
			$email=$this->getRequest()->getPost('email');
			
			$exit = (count($this->getUser($user,$email))==1)? true:false;
			if($exit){
			$password = $this->generatePassword();
			$password_enc = MD5('aFGQ475SDsdfsaf2342'.$password);
			$this->updateUser($user,$email,$password_enc);
			
			$this->sendPasswordByEmail($email, $password);
				return new JsonModel(array('success'=>true));
			}
		return new JsonModel(array('success'=>false));
		}
			
			
			
			
			public function sendPasswordByEmail($email, $password)
			{

				$message = new \Zend\Mail\Message();
				$message->setBody("Votre mot de passe a été modifié. Le nouveau mot de passe est: " .$password);
				$message->setFrom('lyesdjenane@gmail.com');
				$message->addTo($email);
				$message->setSubject('Votre mot de passe a été modifié!');
				
				$smtpOptions = new \Zend\Mail\Transport\SmtpOptions();  
				$smtpOptions->setHost('smtp.gmail.com')
							->setConnectionClass('login')
							->setName('smtp.gmail.com')
							->setConnectionConfig(array(
								'username' => 'lyesdjenane@gmail.com',
								'password' => 'lyesdjenane2014',
								'ssl' => 'tls',
							));
				
				$transport = new \Zend\Mail\Transport\Smtp($smtpOptions);
				$transport->send($message);
			}
			
			
			
			public function getStaticSalt()
			{
				$staticSalt = '';
				$config = $this->getServiceLocator()->get('Config');
				$staticSalt = $config['static_salt'];
				return $staticSalt;
			}
			
			public function generatePassword($l = 8, $c = 0, $n = 0, $s = 0) {
				// get count of all required minimum special chars
				$count = $c + $n + $s;
				$out = '';
				// sanitize inputs; should be self-explanatory
				if(!is_int($l) || !is_int($c) || !is_int($n) || !is_int($s)) {
					trigger_error('Argument(s) not an integer', E_USER_WARNING);
					return false;
				}
				elseif($l < 0 || $l > 20 || $c < 0 || $n < 0 || $s < 0) {
					trigger_error('Argument(s) out of range', E_USER_WARNING);
					return false;
				}
				elseif($c > $l) {
					trigger_error('Number of password capitals required exceeds password length', E_USER_WARNING);
					return false;
				}
				elseif($n > $l) {
					trigger_error('Number of password numerals exceeds password length', E_USER_WARNING);
					return false;
				}
				elseif($s > $l) {
					trigger_error('Number of password capitals exceeds password length', E_USER_WARNING);
					return false;
				}
				elseif($count > $l) {
					trigger_error('Number of password special characters exceeds specified password length', E_USER_WARNING);
					return false;
				}
			
				// all inputs clean, proceed to build password
			
				// change these strings if you want to include or exclude possible password characters
				$chars = "abcdefghijklmnopqrstuvwxyz";
				$caps = strtoupper($chars);
				$nums = "0123456789";
				$syms = "!@#$%^&*()-+?";
			
				// build the base password of all lower-case letters
				for($i = 0; $i < $l; $i++) {
					$out .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
				}
			
				// create arrays if special character(s) required
				if($count) {
					// split base password to array; create special chars array
					$tmp1 = str_split($out);
					$tmp2 = array();
			
					// add required special character(s) to second array
					for($i = 0; $i < $c; $i++) {
						array_push($tmp2, substr($caps, mt_rand(0, strlen($caps) - 1), 1));
					}
					for($i = 0; $i < $n; $i++) {
						array_push($tmp2, substr($nums, mt_rand(0, strlen($nums) - 1), 1));
					}
					for($i = 0; $i < $s; $i++) {
						array_push($tmp2, substr($syms, mt_rand(0, strlen($syms) - 1), 1));
					}
			
					// hack off a chunk of the base password array that's as big as the special chars array
					$tmp1 = array_slice($tmp1, 0, $l - $count);
					// merge special character(s) array with base password array
					$tmp1 = array_merge($tmp1, $tmp2);
					// mix the characters up
					shuffle($tmp1);
					// convert to string for output
					$out = implode('', $tmp1);
				}
			
				return $out;
			}
	public function getEntityManager()
	{
		return $this
					->getServiceLocator()
					->get('Doctrine\ORM\EntityManager');
	
	}
	public function getUser($name,$email){
		return $this->getEntityManager()->createQuery("select u.user_name,u.passwd from Administration\Model\Entity\User as u where u.user_name='$name' and u.email='$email' ")->execute();
	}
	
	public function updateUser($name,$email,$password){
        return $this->getEntityManager()->createQuery("update Administration\Model\Entity\User as u set u.passwd='$password' where u.user_name='$name' and u.email='$email'")->execute();
    }

	
	
}
