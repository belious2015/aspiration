<?php
namespace Administration\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;
use Administration\Model\Entity\Projet;
use Administration\Model\Entity\User;
use Administration\Model\Entity\Spider;
use Doctrine\ORM\EntityManager;
use Zend\ServiceManager\Exception;


class SettingsController extends AbstractActionController
{
	private $num=1;
	

	public function parametresAction(){
		$auth = $this->getServiceLocator()->get('Zend\Authentication\AuthenticationService');
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();
		}else{
			return $this->redirect()->toRoute('admin',array('controller'=>'auth', 'action'=>'login'));	
		}
		
		$projets = $this->getProjects();
		$this->layout('layout/admin-layout');
		$this->layout()->setVariable('user', $identity->getUser_name());
		$projets = $this->addStatus($projets);
		return new ViewModel(array('scrapy_projects' => $projets));
	}
	public function userParamAction(){
		$auth = $this->getServiceLocator()->get('Zend\Authentication\AuthenticationService');
		if ($auth->hasIdentity()) {
			$identity = $auth->getIdentity();
		}else{
			return $this->redirect()->toRoute('admin',array('controller'=>'auth', 'action'=>'login'));	
		}
		
		$users = $this->getUsers();
		$this->layout('layout/admin-layout');
		$this->layout()->setVariable('user', $identity->getUser_name());
		return new ViewModel(array('users' => $users));
	}

	public function ajouterProjetAction(){
		if ($_SERVER['REQUEST_METHOD'] == 'POST'){
		    $nom = isset($_POST['nom']) ? $_POST['nom'] : "Scrapy_".$this->num;
		    $this->num += 1;

		    $public = getcwd() . '/public';
		    chdir($public.'/projets_scrapy/');
		    $path = $public.'/projets_scrapy/'.$nom;
		    $command = escapeshellcmd('scrapy startproject '.$nom);
		    $output = shell_exec($command);
		    shell_exec(escapeshellcmd("chmod 777 -R $nom"));
		    chdir('../../');
		    $success = false;
		    if (strpos($output, 'New Scrapy project') !== false) {
			 $success = true;
			 //ajout à la base de données
			$projet=new Projet();
	    	$this->fillProject($projet,array("design"=>$nom,"path"=>$path));
			try{
				$this->getEntityManager()->persist($projet);
				$this->getEntityManager()->flush($projet);
				
			}catch(\Exception $e){
				echo $e->getMessage();
			} 
		    }
		    $this->layout('layout/admin-layout');
		    return new ViewModel(array('success'=>$success,'nom' => $nom ,'output' => $output));
		}
		  
		
	 }
	 public function removeProjectAction(){
		$config = $this->getServiceLocator()->get('Config');
		$scrapyd = $config['scrapyd']['host'];
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$nom = $request->getPost('nom');
			$path = $request->getPost('path');
			try{

				//requete pour supprimer le projet de scrapyd
				$params = array(
					"project" => $nom
				 );
				$output = $this->httpPost($scrapyd."delproject.json",$params);
				$json_arr = json_decode($output, TRUE);
					system('/bin/rm -rf ' . escapeshellarg($path));
					$this->deleteProjectSpiders($path);
					$this->deleteProject($path);
					$ret = array('success'=>true);

			}catch(\Exception $e){
				print_r($e->getMessage());
			}
		}
		return new JsonModel($ret);
	 }
	public function deployerProjectAction(){
		$config = $this->getServiceLocator()->get('Config');
		$scrapyd = $config['scrapyd']['host'];
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$nom = $request->getPost('nom');
			$path = $request->getPost('path');
			try{
				$this->replace_file($path.'/scrapy.cfg', '#url = http://localhost:6800/', $scrapyd);
				
				chdir($path);
				$command = escapeshellcmd('scrapyd-deploy -p '.$nom);
				$output = shell_exec($command);
				$json_arr = json_decode($output, TRUE);
				if ($json_arr["status"] == "ok"){
					$this->setDeployed($path);
					$ret = array('success'=>true,'output'=>$output);
				}else $ret = array('success'=>false,'output'=>$output);
				
			}catch(\Exception $e){
				//print_r($e->getMessage());
			}
			return new JsonModel($ret);
		}
	 }
	 
	 public function addUserAction(){
		$request = $this->getRequest();	
		if ($request->isPost())
		{
			$username = $request->getPost('username');
			$passwd = $request->getPost('password');
			$passwd = MD5('aFGQ475SDsdfsaf2342'.$passwd);
			$email = $request->getPost('email');
			$user = new User();
			$user->setUser_name($username);
			$user->setPasswd($passwd);
			$user->setEmail($email);
			$this->getEntityManager()->persist($user);
			$this->getEntityManager()->flush($user); 
			$data = new JsonModel(array(
				'success' => true,		
			));
			return $data;	
			}	
	 }
	public function refreshProjectAction(){
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$projets = $this->getProjects();
			$projets = $this->addStatus($projets);
			return new JsonModel(array('success'=>true,'projets'=>$projets));
			
		}
	}
	
		public function fillProject($projet,$data){
			$projet->__set("design", $data['design']);
			$projet->__set("path", $data['path']);
			$projet->__set("is_deployed", 0);
    	}
		
		public function addStatus($projets){
			$prj = $this->getListDeployedProjects();
			$cpt = count($projets);
			for($i=0;$i<$cpt;$i++){
				if(in_array($projets[$i]['design'], $prj)) $projets[$i]['status']='deployé';
				else $projets[$i]['status']='non deployé';
			}	
			return $projets;
		}
		public function getListDeployedProjects(){
			$config = $this->getServiceLocator()->get('Config');
			$scrapyd = $config['scrapyd']['host'];
			//http://localhost:6800/listprojects.json
			$output = $this->httpGet($scrapyd."listprojects.json");
			$json_arr = json_decode($output, TRUE);
			if($json_arr['status']=='ok') return $json_arr['projects'];
			else return array();
		}
		
	/**
	 * @return EntityManager
	 */
	public function getEntityManager()
	{
		return $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
	
	}
	
       /**
	* @return array of scrapy projects
	*/
	public function getProjects(){
		return $this->getEntityManager()->createQuery("select e.design, e.path, e.is_deployed from Administration\Model\Entity\Projet as e")->execute();
	}
	
	       /**
	* @return array of scrapy projects
	*/
	public function getUsers(){
		return $this->getEntityManager()->createQuery("select u.user_name,u.email from Administration\Model\Entity\User as u")->execute();
	}

       /**
	* @return boolean
	* delete a scrapy project
	*/
	public function deleteProject($path){
		return $this->getEntityManager()->createQuery("delete from Administration\Model\Entity\Projet as e
									 where e.path='".$path."'")->execute();	
	}

	public function deleteProjectSpiders($path){
		$id = $this->getID($path)[0]['id_projet'];
		return $this->getEntityManager()->createQuery("delete from Administration\Model\Entity\Spider as s
									 where s.id_projet='".$id."'")->execute();
	}

	public function getID($path){
		return $this->getEntityManager()->createQuery("select e.id_projet from Administration\Model\Entity\Projet as e
									where e.path='".$path."'")->execute();	
	}
	public function setDeployed($path){
		return $this->getEntityManager()->createQuery("update Administration\Model\Entity\Projet as p set p.is_deployed='1'
									where p.path='".$path."'")->execute();	
	}

	
	
	public function rrmdir($dir) { 
	  foreach(glob($dir . '/*') as $file) { 
	    if(is_dir($file)) rrmdir($file); else unlink($file); 
	  }
	  rmdir($dir); 
	}
	public function httpGet($url){
		$ch = curl_init();  
	 
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	//  curl_setopt($ch,CURLOPT_HEADER, false); 
	 
		$output=curl_exec($ch);
	 
		curl_close($ch);
		return $output;
	}
	public function httpPost($url,$params){
	  $postData = '';
	   //create name value pairs seperated by &
	   foreach($params as $k => $v) 
	   { 
		  $postData .= $k . '='.$v.'&'; 
	   }
	   $postData = rtrim($postData, '&');
	 
		$ch = curl_init();  
	 
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_HEADER, false); 
		curl_setopt($ch, CURLOPT_POST, count($postData));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
	 
		$output=curl_exec($ch);
	 
		curl_close($ch);
		return $output; 
	}

	function replace_file($path, $string, $replace)
	{
		set_time_limit(0);
	
		if (is_file($path) === true)
		{
			$file = fopen($path, 'r');
			
			$temp = tempnam('./', 'tmp');
	
			if (is_resource($file) === true)
			{
				while (feof($file) === false)
				{
					file_put_contents($temp, str_replace($string, $replace, fgets($file)), FILE_APPEND);
				}
	
				fclose($file);
			}
	
			unlink($path);
		}
	
		return rename($temp, $path);
	}




	
}


