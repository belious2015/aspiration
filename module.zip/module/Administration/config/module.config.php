<?php
return array(
		'controllers' => array(
			'invokables' => array(
				'admin' => 'Administration\Controller\AdminController',
				'spider' => 'Administration\Controller\SpiderController',
				'data' => 'Administration\Controller\DataController',
				'settings' => 'Administration\Controller\SettingsController',
				'auth'  => 'Administration\Controller\AuthController',
					),
					),
		
		'router' => array(
				'routes' => array(
					'admin' => array(
					'type' => 'segment',
					'options' => array(
							'route' => '/[:controller][/:action][/:id]',
							'constraints' => array(
									'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
									'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
									'id' => '[a-zA-Z][a-zA-Z0-9_-]*',
									
										),

					

					'defaults' => array(
							'controller' => 'auth',
							'action' => 'login',
							   ),
							   ),
						  ),
                   
                    
                'logout' => array(
                    'type'    => 'Literal',
                    'options' => array(
                        'route'    => '/auth',
                        'defaults' => array(
                            'controller' => 'auth',
                            'action'     => 'logout',
                        ),
                    ),
					),
                    
                    
                    
                    
                    
					),
					

				),

				'child_routes' => array(
							'default' => array(
							'type'    => 'Segment',
							'options' => array(
							'route'    => '/admin/[:controller[/:action]]',
							'constraints' => array(
										'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
										'action'     => '[a-zA-Z][a-zA-Z0-9_-]*',
										),
									  ),

									   ),
							),


		'view_manager' => array(
				'display_not_found_reason' => true,
				'display_exceptions'       => true,
				'doctype'                  => 'HTML5',
				'not_found_template'       => 'error/404',
				'exception_template'       => 'error/index',
				'template_map' => array(
						'admin/layout'		  =>__DIR__ . '/../view/layout/admin-layout.phtml',
						'administration/index/index' => __DIR__ . '/../view/administration/index/index.phtml',
						'error/404'               => __DIR__ . '/../view/error/404.phtml',
						'error/index'             => __DIR__ . '/../view/error/index.phtml',
				),
				'template_path_stack' => array(
					'administration' => __DIR__ . '/../view',
							),
				'strategies' => array(
						'ViewJsonStrategy',
					 ),
							),
				//configuration de doctrine
				'doctrine' => array(
						'authentication' => array(
								'orm_default' => array(
										//should be the key you use to get doctrine's entity manager out of zf2's service locator
										'object_manager' => 'Doctrine\ORM\EntityManager',
										//fully qualified name of your user class
										'identity_class' => 'Administration\Model\Entity\User',
										//the identity property of your class
										'identity_property' => 'user_name',
										//the password property of your class
										'credential_property' => 'passwd',
										//a callable function to hash the password with
										'credential_callable' => 'Administration\Model\Entity\User::hashPassword'
								),
						),
						'driver' => array(
								'application_entities' => array(
										'class' => 'Doctrine\ORM\Mapping\Driver\AnnotationDriver',
										'cache' => 'array',
										'paths' => array(__DIR__ . '/../src/Administration/Model/Entity')
								),
								'orm_default' => array(
										'drivers' => array(
												'Administration\Model\Entity' => 'application_entities'
										)
								)),
				),
					
		'console' => array (
				'router' => array (
					'routes' => array (
					'correction' => array(
						'options' => array(
							'route'    => 'cor',
							'defaults' => array(
								'controller' => 'data',
								'action'     => 'cor'
							)
						)
					),
				    'nettoyage' => array(
						'options' => array(
							'route'    => 'net',
							'defaults' => array(
								'controller' => 'data',
								'action'     => 'net'
							)
						)
					),
					)
				),
		),
        'scrapyd'=>array(
            'host'=>'http://localhost:6800/',
        )

);
