<?php
namespace Services;
use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\ModuleManager\Feature\ConfigProviderInterface;
use Zend\ModuleManager\Feature\BootstrapListenerInterface;
use Zend\Mvc\MvcEvent;



class Module
{
		public function getAutoloaderConfig()
		{
		return array(
				'Zend\Loader\ClassMapAutoloader' => array(
				__DIR__ . '/autoload_classmap.php',
				),
				'Zend\Loader\StandardAutoloader' => array(
				'namespaces' => array(
				__NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
				),
				),
		);
		}
		public function getConfig()
		{
		return include __DIR__ . '/config/module.config.php';
		}


		public function getServiceConfig()
			{
				return array(
				);
			}
		
	
		public function onBootstrap(MvcEvent $e)
		{
			$application = $e->getApplication();
			$em = $application->getEventManager();
			//handle the dispatch error (exception) 
			$em->attach(\Zend\Mvc\MvcEvent::EVENT_DISPATCH_ERROR, array($this, 'handleError'));
			//handle the view render error (exception) 
			$em->attach(\Zend\Mvc\MvcEvent::EVENT_RENDER_ERROR, array($this, 'handleError'));
		}
		public function handleError(MvcEvent $e)
		{
			//get the exception
			$exception = $e->getParam('exception');
			echo $exception;
			//...handle the exception... maybe log it and redirect to another page, 
			//or send an email that an exception occurred...
		}

}
