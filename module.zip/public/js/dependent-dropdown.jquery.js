/**
 * dependentDropDown()
 * ------------------------------
 * Fonction pour peupler un �l�ment select au changement d'un autre �l�ment
 * @param source : id de l'�l�ment source
 * @param traget : id de l'�l�ment qui r�agit au changement
 * @param url : l'url de l'action � executer dans le controller
 *  
 * @require : jQuery
 * @date    : 14-08-2013
 * @author  : Mounir Hamoudi
 * 
 */
dependentDropDown = function(source,target,url){
    // si la cible est vide on la verrouille...
    if($('#'+target+' option').length <= 1) 
      $('#'+target).prop('disabled', true);
    
    $('#'+source).change(function() {
		 if($('#'+source).val() != '')
		 {
            $.ajax({
                type:  'POST',
                async: true,
                url:   url,
                cache: true,
                data:  {val: $('#'+source).val() },
                success: function(data){
                    if(data.success)
                    {
                		if(data.results != ""){
						  $('#'+target).find('option').remove().end();
    
                            $('#'+target).prop('disabled', false);
							var options = new Array();
                            $.each(data.results, function(key, value){
                               $("#"+target).append($('<option value="' + key + '">' + value + '</option>'));
                            });
                        }
						else{
							$('#'+target).find('option').remove().end();
                             $('#'+target).prop('disabled', true);
						}
                    }
                },
                error: function(jqXHR,textStatus,errorThrown){
                    var error = $.parseJSON(jqXHR.responseText);
                    var content = error.content;
                    console.log(content.message);
                    if(content.display_exceptions)
                        console.log(content.exception.xdebug_message);
                },
                dataType: 'json'
            });
        }else{
            $('#'+target).find('option').remove().end();
            $('#'+target).prop('disabled', true);
        }
    });
}