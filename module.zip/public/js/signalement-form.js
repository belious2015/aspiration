var index_selected_damage; //selected damage from the damages table
var index_selected_temoins; //selected witness from the witnessess table
var index_selected_actionsIm; //selectd action from the immediate actions table
var damages = {}; // added damages
var witness = {}; //added witnessess
var actionsIm={}; //added actions

var nbr_damage = 0; // number of added damages.
var nbr_witness = 0; //number of added witnessess.
var nbr_actionIm=0; //number of added actions.

$(document).ready(function(){

/*-----------------show/hide 'corporal damages' section---------------*/
$('#event_category').change(function(){
		var show=$('#event_category option:selected').val();
		if(show=='hse'){
			$('#hide_damage').css('display','inline');
		}
		else{
			$('#hide_damage').css('display','none');	
		}
	});
/**----------------------------------------*/
$('<input type="hidden" name ="posted_damages" id="damages_to_submit" value="" />').appendTo("#Event");
$('<input type="hidden" name ="posted_witness" id="witness_to_submit" value="" />').appendTo("#Event");
$('<input type="hidden" name ="posted_actions" id="actions_to_submit" value="" />').appendTo("#Event");

/*--------------Inisilize the datePicker-----------------------*/
$('#date_incid').Zebra_DatePicker({
        format: 'Y-m-d',
        inside : false
        
    });
	
/*----------------------table selection highlighting--------------------*/
	$(".table_to_fill").on('click', 'tr', function(){
    $(this).addClass("selected").siblings().removeClass("selected");
    var id_table = jQuery(this).parents('table').attr('id').toString();
    if(id_table=="corporal_damages"){
    index_selected_damage = this.rowIndex;
    }
    else{
     if(id_table=="witness_table"){
    	 index_selected_temoins =  this.rowIndex; 
     }
     else if(id_table=="action_immediate_table"){
    	 index_selected_actionsIm =  this.rowIndex; 
     }

     }
});

/*----------------------delete selected damage from table--------------------*/
$("#delete_damage_button").click(function(){
	var id = $("#corporal_damages tr:eq("+index_selected_damage+")").attr('id');
	delete damages[id];
	jsonString = JSON.stringify(damages);
	$('#damages_to_submit').attr('value', jsonString);
	$("#corporal_damages tr:eq("+index_selected_damage+")").remove();
	
});

/*----------------------delete selected witness from table--------------------*/
$("#delete_button_witness").click(function(){
	var id = $("#witness_table tr:eq("+index_selected_temoins+")").attr('id');
	delete witness[id];
	jsonString = JSON.stringify(witness);
	$('#witness_to_submit').attr('value', jsonString);
	$("#witness_table tr:eq("+index_selected_temoins+")").remove();
});

/*----------------------delete selected action from table--------------------*/
$("#delete_button_actionIm").click(function(){
	var id = $("#action_immediate_table tr:eq("+index_selected_actionsIm+")").attr('id');
	delete actionsIm[id];
	jsonString = JSON.stringify(actionsIm);
	$('#actions_to_submit').attr('value', jsonString);
	$("#action_immediate_table tr:eq("+index_selected_actionsIm+")").remove();
});

/*----------------------add damage to table--------------------*/
$("#add_damage_button").click(function(){
	
	var desig_incident=$('#type_incident_hs option:selected').text();
	var type_incident=$('#type_incident_hs option:selected').val();
	var description=$('#desc_blessure').val();
	
	$('#corporal_damages tr:last').after('<tr id="damage'+(nbr_damage+1)+'"><td>'+type_incident+'</td><td>'+description+'</td></tr>');
	
	var sexe=$('input[type=radio][name=sexe_radio]:checked').attr('value');
	var origine=$('input[type=radio][name=origine_radio]:checked').attr('value');
	var trait=$('input[type=radio][name=traitement_radio]:checked').attr('value');
	var trainer=null;
	if(trait=='tr2'){trainer=$('#trainer_id').val();}
	else if(trait=='tr3'){trainer=$('#trainer_id').val();}

	var item = {};
	
	item["type"] =type_incident;
	item["desig"]=desig_incident;
	item["desc"] =description;
	item["sexe"] =sexe;
	item["origine"]=origine;
	item["traitement"] =trait;
	item["trainer"] =trainer;
	
	damages['damage'+(nbr_damage+1)+'']=item;
	
	jsonString = JSON.stringify(damages);
	$('#damages_to_submit').attr('value', jsonString);
	nbr_damage++;
});

/*----------------------add witness to table--------------------*/
$("#add_button_witness").click(function(){
	
	var witness_name=$('#witness_name').val();
	var societe=$('#witness_soc :selected').text();
	var position=$('#witness_pos').val();
	
	$('#witness_table tr:last').after('<tr id="witness'+(nbr_witness+1)+'"><td>'+witness_name+'</td><td>'+societe+'</td><td>'+position+'</td></tr>');

	var item = {};
	
	item["name"] =witness_name;
	item["society"] =societe;
	item["position"] =position;
	
	witness['witness'+(nbr_witness+1)+'']=item;
	
	jsonString = JSON.stringify(witness);
	$('#witness_to_submit').attr('value', jsonString);
	nbr_witness++;
});

/*----------------------add action to table--------------------*/
$("#add_button_actionIm").click(function(){
	
	var desc=$('#action_immediate_desc').val();
	var resp=$('#action_immediate_responsable').val();
	
	$('#action_immediate_table tr:last').after('<tr id="action'+(nbr_actionIm+1)+'"><td>'+desc+'</td><td>'+resp+'</td></tr>');

	var item = {};
	
	item["desc"] =desc;
	item["resp"] =resp;
	
	actionsIm['action'+(nbr_actionIm+1)+'']=item;
	
	jsonString = JSON.stringify(actionsIm);
	$('#actions_to_submit').attr('value', jsonString);
	nbr_actionIm++;
});
});

/*-------show/hide 'other society' field-------------------------*/
$(function()
{
$(':radio[value="oth"]').click(function(){
	$('#other_society').css('display', 'inline');
	$('#other_society').addClass('validate[required]');
});

$(':radio[value="og"]').click(function(){
	$('#other_society').css('display', 'none');
	$('#other_society').removeClass('validate[required]');
});
});

/*-------show/hide 'traitement_responsible' field-------------------------*/
$(function()
		{
		$(':radio[value="tr2"]').click(function(){
			$('#traitement_responsible').css('display', 'inline');
			$('#traitement_responsible').addClass('validate[required]');
		});

		$(':radio[value="tr3"]').click(function(){
			$('#traitement_responsible').css('display', 'inline');
			$('#traitement_responsible').addClass('validate[required]');
		});

		$(':radio[value="tr1"]').click(function(){
			$('#traitement_responsible').css('display', 'none');
			$('#traitement_responsible').removeClass('validate[required]');
		});
		$(':radio[value="tr4"]').click(function(){
			$('#traitement_responsible').css('display', 'none');
			$('#traitement_responsible').removeClass('validate[required]');
		});


		
});
