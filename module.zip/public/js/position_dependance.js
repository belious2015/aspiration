getCorrespondant = function(url){
    // si la cible est vide on la verrouille...
    if($('#receiver_position'+' option').length <= 1) 
      $('#receiver_position').prop('disabled', true);
    
	$('#receiver_name').change(function() {
		 if($('#receiver_name').val() != '')
		 {
            $.ajax({
                type:  'POST',
                async: true,
                url:   url,
                cache: true,
                data:  {val: $('#receiver_name').val() },
                success: function(data){
                    if(data.success)
                    {
                		if(data.result != ""){
						  $('#receiver_position').find('option').remove().end();
						  $("#receiver_position").attr('value',data.result);							
                        }
						else{
							$('#receiver_position').find('option').remove().end();
                             $('#receiver_position').prop('disabled', true);
						}
                    }
                },
                error: function(jqXHR,textStatus,errorThrown){
                    var error = $.parseJSON(jqXHR.responseText);
                    var content = error.content;
                    console.log(content.message);
                    if(content.display_exceptions)
                        console.log(content.exception.xdebug_message);
                },
                dataType: 'json'
            });
        }else{
            $('#receiver_position').find('option').remove().end();
            $('#receiver_position').prop('disabled', true);
        }
    });
}
