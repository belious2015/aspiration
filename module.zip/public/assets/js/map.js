
    /*declaration des variables*/
      var map;
      var markers = [];
      
      
      google.maps.event.addDomListener(window, 'load', initialize);
        /*
        * initialisation de la carte
        */
          function initialize() {
            var mapOptions = {
              center: { lat: 36.75, lng: 3.033},
              zoom: 8,
            };
            map = new google.maps.Map(document.getElementById('carte'),mapOptions);
            
            annonces = [];
            annonces  = getAnnoncesIds();
            var cpt = 0;
            for(i=0;i<annonces.length;i++){
              (function(item){
                getAnnonceDetails(item,function(data){
                  latlong = null;
                  if (data.details!=null && (data.longitude!=0 || data.lattitude!=0)) {
                    var nb = existeMarker(data.lattitude,data.longitude);
                    if (nb>=1) latlong = getNewLatLon(data.lattitude,data.longitude,nb);
                    else  latlong = new google.maps.LatLng(data.lattitude,data.longitude);
                    pin = addmarker(map,latlong,data.details.bien,data.details.annonce);
                    infoWin = getInfoWindowHtml(data.details,1);
                    info  = customizeMarker(infoWin,pin,map);
                    styleInfoWindow(info);
                    markers.push({'marker':pin,'lat':data.lattitude,'lon':data.longitude,'info':infoWin,'type_annonce':data.details.annonce,'type_bien':data.details.bien,'display':true});
                  }
                });
                })(annonces[cpt]);
              cpt = cpt + 1;

            }
      
          }
          
          function refreshMap(filtre_annonce,filtre_bien,annonces) {
            removeAllMarkers(markers);
            markers = [];
            //annonces  = getAnnoncesIds();
            var cpt = 0;
            for(i=0;i<annonces.length;i++){
              //get position
              (function(item){
                getPosition(item.quartier,item.commune, item.wilaya, function(data){
                var latlong = null;
                if (data!=null && (data.longitude!='0' || data.lattitude!='0')) {
                    var nb = existeMarker(data.lattitude,data.longitude);
                    if (nb>=1) latlong = getNewLatLon(data.lattitude,data.longitude,nb);
                    else latlong = new google.maps.LatLng(data.lattitude,data.longitude);
                    var pin = addmarker(map,latlong,item.bien,item.annonce);
                    var infoWin = getInfoWindowHtml(item,2);
                    var info  = customizeMarker(infoWin,pin,map);
                    styleInfoWindow(info);
                    markers.push({'marker':pin,'lat':data.lattitude,'lon':data.longitude,'info':infoWin,'type_annonce':item.annonce,'type_bien':item.bien,'display':true});
                }
                });
                              
                })(annonces[cpt]);
                cpt = cpt + 1;


            }
          }
          function existeMarker(lat,lon) {
            var ret = 0;
            for (i=0;i<markers.length;i++) {
              if (markers[i].lat == lat && markers[i].lon == lon) ret = ret + 1;
            }
            return ret;
          }
          function getNewLatLon(lat,lon,nb) {
            var a = 360.0 / 10;
            var newLat = lat + -.001 * Math.cos((+a*nb) / 180 * Math.PI);  //x
            var newLng = lon + -.001 * Math.sin((+a*nb) / 180 * Math.PI);  //Y
            return new google.maps.LatLng(newLat,newLng);
          }
          function zoomMap(zoom,center) {
            if (center=="") center = "alger";
            getPosition("","",center,function(data){
              latlong = new google.maps.LatLng(data.lattitude,data.longitude);
              map.setCenter(latlong);
              map.setZoom(zoom);
            });
            
          }
          
          function refreshMarkers(filtre_annonce,filtre_bien,annonces) {
            for (i=0;i<markers.length;i++) {
              pos_1 = getActionPos(markers[i].type_annonce);
              pos_2 = getTypePos(markers[i].type_bien);
                if (!filtre_annonce[pos_1]) {
                    hideMarker(markers[i]);
                }else if (!filtre_bien[pos_2]) {
                    hideMarker(markers[i]);
                }else if(!markers[i].display) showMarker(markers[i]);
            }
          }
          function hideMarker(marker) {
            marker.display = false;
            removeMarker(marker.marker);
          }
          function showMarker(marker) {
            marker.marker = addmarker(map,new google.maps.LatLng(marker.lat,marker.lon),marker.type_bien,marker.type_annonce);
            info  = customizeMarker(marker.info,marker.marker,map);
            styleInfoWindow(info);
            marker.display = true;
          }
          
          //cette fonction determine si on doit afficher le marqueur ou pas(selon les filtres choisis);
          function isToAdd(annonce,bien,filtre_annonce,filtre_bien) {
            var ret = true;
            if (!filtre_annonce[getActionPos(annonce)]) ret = false;
            else if (!filtre_bien[getTypePos(bien)]) ret = false;
            return ret;
          }
          
          function getActionPos(action) {
            switch (action) {
                case 'location':
                  return 0;
                  break;
                case 'vente':
                  return 1;
                  break;
                case 'colocation':
                  return 2;
                  break;
                case 'echange':
                  return 3;
                  break;
                default:
                  return 4;
            }
          }
          function getTypePos(action) {
            switch (action) {
                case 'appartement':
                  return 0;
                  break;
                case 'villa':
                  return 1;
                  break;
                case 'local':
                  return 2;
                  break;
                case 'duplex':
                  return 3;
                  break;
                case 'immeuble':
                  return 4;
                  break;
                case 'usine':
                  return 5;
                  break;
                case 'terrain':
                  return 6;
                  break;
                default:
                  return 7;
            }
          }
          
          
          function styleInfoWindow(infowindow) {
                    google.maps.event.addListener(infowindow, 'domready', function () {

                    var iwOuter = $('.gm-style-iw');

                    var iwBackground = iwOuter.prev();

                    iwBackground.children(':nth-child(2)').css({'display': 'none'});

                    iwBackground.children(':nth-child(4)').css({'display': 'none'});

                    iwOuter.parent().parent().css({left: '26px'});

                    iwBackground.children(':nth-child(1)').attr('style', function (i, s) {
                        return s + 'display: none !important;'
                    });

                    iwBackground.children(':nth-child(3)').attr('style', function (i, s) {
                        return s + 'left: 128px !important; margin-top: -10px; z-index: 0;'
                    });

                    iwBackground.children(':nth-child(3)').find('div').children().css({'box-shadow': 'rgba(255, 255, 255, 0.1) 0px 1px 6px', 'z-index': '1'});

                    var iwCloseBtn = iwOuter.next();

                    iwCloseBtn.css({
                        opacity: '1',
                        right: '48px', top: '14px',
                        width: '19px', height: '19px',
                        border: '3px solid #ffffff',
                        'border-radius': '17px',
                        'background-color': '#ffffff'
                    });

                    iwCloseBtn.mouseout(function () {
                        $(this).css({opacity: '1'});
                    });

                });
          }

          
          





    /*
    * cette fonction permet d'attacher un evenement de click � un marqueur
    * et d'afficher une info bulle lors d'un clic sur ce dernier
    */
    function customizeMarker(infoWindowHtml,marker,map){
      var info = new google.maps.InfoWindow({
            content: infoWindowHtml,
            maxWidth: 350,
        });
       marker.setDraggable(false);
       google.maps.event.addListener(marker, 'click', function() {
         //adding the infoWindow
         info.open(map, marker);
       });
       return info;
    }

    
    //ajout d'un marker
    function addmarker(map,latilongi,type,type_annonce) {
        var titre = '';
        var path = '/assets/img/';

        switch (type_annonce) {
            case 'vente':
              path = path + 'vente/';
              titre = 'vente';
            break;
            case 'location':
              path = path + 'location/';
              titre = 'location';
            break;
            case 'colocation':
              path = path + 'colocation/';
              titre = 'colocation';
            break;
            case 'echange':
              path = path + 'echange/';
              titre = 'echange';
            break;
            default:
              path = path + 'autre/';
              titre = 'annonce';
            break;
        }
        switch (type) {
          case 'appartement':
            path = path + 'appartement.png';
            titre = 'appartement pour ' + titre;
          break;
          case 'villa':
            path = path + 'villa.png';
            titre = 'villa pour ' + titre;
          break;
          case 'terrain':
            path = path + 'terrain.png';
            titre = 'villa pour ' + titre;
          break;
          case 'duplex':
            path = path + 'duplex.png';
            titre = 'duplex pour ' + titre;
          break;
          case 'local':
            path = path + 'local.png';
            titre = 'local pour ' + titre;
          break;
          case 'immeuble':
            path = path + 'immeuble.png';
            titre = 'immeuble pour ' + titre;
          break;
          case 'usine':
            path = path + 'usine.png';
            titre = 'usine pour ' + titre;
          break;
          default:
            path = path + 'autre.png';
            titre = 'aautre bien pour ' + titre;
          break;
        }

        var marker = new google.maps.Marker({
            position: latilongi,
            title: titre,
            draggable: true,
            icon:path ,
            map: map,
        });
        //map.setCenter(marker.getPosition());
        return marker;
    }
    
    //le contenu html d'une info bulle
    function getInfoWindowHtml(annonce,from){
      if (from == 1) img = annonce["photos"][0];
      else img = annonce["photos"][0];
      if (img !== null && typeof img === 'object') {
        img = img['photo'];
      }
      var content = '<div class="map-info-window"> '+
                      '<div class="thumbnail no-border no-padding thumbnail-property-card">'+
                        '<div class="media">'+
                          '<a class="media-link" data-gal="prettyPhoto" target="_blank" href="'+img+'">'+
                            '<img src="'+img+'" alt="" style="max-height: 150px;width: 100%;" />'+
                            '<span class="icon-view"><strong><i class="fa fa-arrows-alt"></i></strong></span>'+
                          '</a>'+
                        '</div>'+
                        '<div class="caption text-center">'+
                            '<div class="caption-text">'+annonce["annonce"]+'</div>'+
                            '<div class="caption-text">'+annonce["bien"]+'</div>' + 
                              '<h4 class="caption-title" style="max-height: 40px;overflow: hidden;"><a target="_blank" href="http://darna.admin/client/display_details/'+annonce["id"]+'">'+annonce["titre"]+'</a></h4>'+
                              '<div class="caption-text" style="max-height: 40px;overflow: hidden;">'+annonce["description"]+'</div>'+
                              '<div class="buttons">'+
                                '<a class="btn btn-theme ripple-effect" href="'+annonce["lien"]+'" target="_blank">Suivre</a>'+
                                '</div>'+
                                '<table class="table">'+
                                  '<tr>'+
                                    '<td><i class="fa fa-expand"></i>'+annonce["superficie"]+'</td>'+
                                    '<td><i class="fa fa-bed"></i>'+annonce["pieces"]+'</td>'+
                                    '<td><i class="fa fa-money"></i>'+annonce["prix"]+' DZ</td>'+
                                  '</tr>'+
                                '</table>'+
                              '</div>'+
                            '</div>'+
                          '</div>';
                          
                          /*
                           *                        
                           **/
        
      var contentString = '<div class="iw-container">' +
                            '<div class="iw-content">' +
                              '' + content+
                            '</div>' +
                            '<div class="iw-bottom-gradient"></div>' +
                          '</div>';
      return contentString;
    }
    
    //enlever un marqueur de la carte
    function removeMarker(marker) {
        marker.setMap(null);
    }
    
    //enlever tous les marqueurs de la carte
    function removeAllMarkers(markersArray) {
      for (var i = 0; i < markersArray.length; i++ ) {
        markersArray[i].marker.setMap(null);
      }
      markersArray.length = 0;
    }
    
    //cette fonction recupere les id des annonces qui sont list�es
    function getAnnoncesIds(){
      var $return=[];
      $('.annonce_id').each(function(){
        $return.push($(this).text());
      });
      return $return;
    }
    
    //cette fonction r�cupere les details d'une annonce
    function getAnnonceDetails(id,callback) {
      $.ajax({type: 'POST', 
              url: 'details', 
              data: { 'id':id },
              dataType: 'json',
              async: true,
              success: function (data) {
                    //construire le tableau
                    callback.call(this,data);
              },
              error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log("erreur de requete ajax");
              }
      });
    }
    //cette fonction r�cupere les details d'une annonce
    function getPosition(quartier,commune,wilaya,callback) {
      $.ajax({type: 'POST', 
              url: 'get_position', 
              data: { 'quartier':quartier, 'commune':commune, 'wilaya':wilaya },
              dataType: 'json',
              async: true,
              success: function (data) {
                    //construire le tableau
                    callback.call(this,data);
              },
              error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log("erreur de requete ajax");
              }
      });
    }
          function getFilterAction() {
                    var checked_1 = [false, false, false, false, false];
                    $.each($("input[name='filter_action[]']:checked"), function() {                       
                        switch ($(this).val()) {
                            case 'location':
                                checked_1[0] = true;
                                break;
                            case 'vente':
                                checked_1[1] = true;
                                break;
                            case 'colocation':
                                checked_1[2] = true;
                                break;
                            case 'echange':
                                checked_1[3] = true;
                                break;
                            case 'autre':
                                checked_1[4] = true;
                                break;
                        }
                    });
                    return checked_1;
            }
            function getFilterType() {
                    var checked_2 = [false, false, false, false, false, false, false, false];
                    $.each($("input[name='filter_type[]']:checked"), function() {
                            switch ($(this).val()) {
                                case 'appartement':
                                    checked_2[0] = true;
                                    break;
                                case 'villa':
                                    checked_2[1] = true;
                                    break;
                                case 'local':
                                    checked_2[2] = true;
                                    break;
                                case 'duplex':
                                    checked_2[3] = true;
                                    break;
                                case 'immeuble':
                                    checked_2[4] = true;
                                    break;
                                case 'usine':
                                    checked_2[5] = true;
                                    break;
                                case 'terrain':
                                    checked_2[6] = true;
                                    break;
                                case 'autre':
                                    checked_2[7] = true;
                                    break;
                            }
                        });
                    return checked_2;
            }
            
    








